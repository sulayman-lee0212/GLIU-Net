# Copyright (c) OpenMMLab. All rights reserved.
from .distributed_sampler import DistributedSampler

__all__ = ['DistributedSampler']
