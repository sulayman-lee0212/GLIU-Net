import pandas as pd
import cv2
import os
import numpy as np

# 读取CSV文件
df = pd.read_csv('/data/code2025/Q1/2025-02-11-01/data/tract/train.csv')
label_dir = "/data/code2025/Q1/2025-02-11-01/data/tract/mmseg_train/labels"
mask_dir = "/data/code2025/Q1/2025-02-11-01/data/tract/mmseg_train/masks"

class_map = {
    'large_bowel': 1,
    'small_bowel': 2,
    'stomach': 3
}

# 按行打印第一列（id）和第二列（class）
for index, row in df.iterrows():
    name = row.iloc[0]
    class_name = row.iloc[1]
    try:
        label_name = name.replace('slice_000', '').replace('slice_00', '').replace('slice_0', '') + '.png'
        label = cv2.imread(os.path.join(label_dir, label_name))
        label = label * class_map[class_name]
        # cv2.imwrite(os.path.join(mask_dir, label_name), label)
        print(label_name, class_name)
    except:
        continue

