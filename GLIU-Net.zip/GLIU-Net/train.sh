#CUDA_VISIBLE_DEVICES=0,1 ./tools/dist_train.sh ./my_config/unet_sam.py 2
#CUDA_VISIBLE_DEVICES=0,1,2,3 ./tools/dist_train.sh ./my_config/debug.py 4
CUDA_VISIBLE_DEVICES=0 nohup ./tools/dist_train.sh ./my_config/unet.py 1 >> exp1.log &
CUDA_VISIBLE_DEVICES=0,1 nohup ./tools/dist_train.sh ./my_config/transunet.py 2 >> exp2.log &
CUDA_VISIBLE_DEVICES=2,3 nohup ./tools/dist_train.sh ./my_config/swinunet.py 2 >> exp3.log &
