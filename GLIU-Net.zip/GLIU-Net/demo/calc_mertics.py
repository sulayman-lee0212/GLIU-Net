import os
import numpy as np
import cv2
from tqdm import tqdm
from medpy.metric.binary import hd95

# 类别定义
class_names = ('background', 'Aorta', 'Gallbladder', 'Kidney_L', 'Kidney_R',
               'Liver', 'Pancreas', 'Spleen', 'Stomach')

# 目录路径
gt_dir = "/data/code2025/Q1/2025-02-07-01/datasets/test/labels"  # 真实标签路径
pred_dir = "/data/code2025/Q1/2025-02-07-01/datasets/pred/unet"  # 预测mask路径

# 计算HD95
def compute_hd95(gt_mask, pred_mask):
    """ 计算HD95，若类别未出现，则返回 NaN """
    try:
        return hd95(pred_mask, gt_mask)
    except RuntimeError:
        return np.nan  # 该类别不存在，返回 NaN

# 统计每个类别的HD95
hd95_scores = {cls: [] for cls in class_names}

# 遍历GT文件，使用 tqdm 添加进度条
file_list = sorted(os.listdir(gt_dir))
for filename in tqdm(file_list, desc="Processing", ncols=80):
    gt_path = os.path.join(gt_dir, filename)
    pred_path = os.path.join(pred_dir, filename)

    if not os.path.exists(pred_path):
        print(f"预测文件缺失: {filename}")
        continue

    # 以灰度模式加载
    gt = cv2.imread(gt_path, cv2.IMREAD_GRAYSCALE)
    pred = cv2.imread(pred_path, cv2.IMREAD_GRAYSCALE)

    if gt is None or pred is None:
        print(f"读取失败: {filename}")
        continue

    for i, cls in enumerate(class_names):
        gt_mask = (gt == i).astype(np.uint8)
        pred_mask = (pred == i).astype(np.uint8)

        if gt_mask.max() > 0 or pred_mask.max() > 0:  # 该类别存在
            score = compute_hd95(gt_mask, pred_mask)
            if not np.isnan(score):
                hd95_scores[cls].append(score)

# 计算每个类别的平均HD95
avg_hd95 = {}
for cls in class_names:
    valid_scores = [s for s in hd95_scores[cls] if not np.isnan(s)]
    avg_hd95[cls] = np.mean(valid_scores) if valid_scores else np.nan

# 打印结果
for cls, score in avg_hd95.items():
    print(f"{cls}: {score:.2f}")

# 计算整体平均HD95
all_scores = [s for scores in hd95_scores.values() for s in scores if not np.isnan(s)]
mean_hd95 = np.mean(all_scores) if all_scores else np.nan
print(f"平均 HD95: {mean_hd95:.2f}")
